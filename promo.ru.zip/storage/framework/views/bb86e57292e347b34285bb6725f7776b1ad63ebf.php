<?php $__env->startSection('title'); ?>
Список сообществ вконтакте
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside'); ?>
    <h3>Добавить ссылку</h3>
    <?php echo e(Form::open()); ?>

    <div class="input-group">
        <?php echo e(Form::label('ссылка на группу вконтакте')); ?>

        <?php echo e(Form::text( 'url', '', ['placeholder' => 'https://vk.com/itcookies'] )); ?>

    </div>
    <?php echo e(Form::submit( 'Добавить', ['class' =>'btn btn-primary', 'style' => 'margin-top: 10px; margin-bottom: 10px'] )); ?>

    <?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="table-responsive">
      <table class="table table-hover">
        <thead>
            <th>
                id
            </th>
            <th>
                url
            </th>
            <th>
                эффективность
            </th>
            <th>
                действие
            </th>
        </thead>
        <tbody>
            <?php foreach( $comunities as $comunity ): ?>
                <tr>
                    <td>
                        <?php echo e($comunity->id); ?>

                    </td>
                    <td>
                        <div><?php echo e($comunity->name); ?></div>
                        <a style="font-size: 11px" href="<?php echo e($comunity->url); ?>"><?php echo e($comunity->url); ?></a>
                    </td>
                    <td>
                        <span class="badge"><?php echo e($comunity->efficiency); ?></span>
                    </td>
                    <td>
                        <a href=<?php echo e(route( 'comunity.delete', $comunity->id )); ?> class="btn btn-danger btn-xs">удалить</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="row">
        <div class="col-md-12">
             <?php echo $comunities->links(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make( 'layouts.general' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>