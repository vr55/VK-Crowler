<?php $__env->startSection('title'); ?>
Шаблоны деловых предложений
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside'); ?>
    <?php if( count( $errors ) > 0 ): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach( $errors->all() as $error): ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <h3>Добавить шаблон</h3>
    <?php echo e(Form::open()); ?>

    <div class="input-group">
        <?php echo e(Form::label('Текст шаблона')); ?>

        <?php echo e(Form::textarea( 'proposal', '', ['placeholder' => 'Деловое предложение', 'style' => 'width: 250px'] )); ?>

    </div>
    <?php echo e(Form::submit( 'Добавить', ['class' =>'btn btn-primary', 'style' => 'margin-top: 10px; margin-bottom: 10px'] )); ?>

    <?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="table-responsive">
      <table class="table table-hover">
        <thead>
            <th>
                id
            </th>
            <th>
                текст
            </th>
            <th>
                действие
            </th>
        </thead>
        <tbody>
            <?php foreach( $proposals as $proposal ): ?>
                <tr>
                    <td>
                        <?php echo e($proposal->id); ?>

                    </td>
                    <td>
                        <div><?php echo e($proposal->text); ?></div>
                    </td>
                    <td>
                        <a href=<?php echo e(route( 'proposal.delete', $proposal->id )); ?> class="btn btn-danger btn-xs">удалить</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="row">
        <div class="col-md-12">
             <?php echo $proposals->links(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make( 'layouts.general' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>