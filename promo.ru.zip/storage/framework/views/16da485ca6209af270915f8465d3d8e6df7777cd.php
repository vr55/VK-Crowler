<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

      <a class="navbar-brand" href="/"><img style="display: inline; margin-top: -15px" src="http://www.monochromatic.ru/mc_logo32.png" alt="monochromatic logo" />
         <span> VK&nbsp;Crawler <span style="font-size: 10px">v0.1b</span>
            <div style="font-size:10px; margin-top:-7px;">by monochromatic</div>
        </span>
    </a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="/">Главная</a></li>
        <?php if( Sentinel::check() ): ?>
            <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#">Настройки<span class="caret"></span></a>

              <ul class="dropdown-menu">
                <li><a href=<?php echo e(route( 'settings' )); ?>>Общие</a></li>
                <li><a href=<?php echo e(route( 'comunities' )); ?>>Сообщества вконтакте</a></li>
                <li><a href=<?php echo e(route( 'keywords' )); ?>>Ключевые слова</a></li>
                <li><a href=<?php echo e(route( 'proposal' )); ?>>Шаблоны деловых предложений</a></li>
              </ul>

          </li>
            <a style="margin-top:10px; width: 200px" class="btn btn-primary" style="width: 120px" href=<?php echo e(route( 'update' )); ?>>Update</a>
        <?php endif; ?>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <?php if( Sentinel::check() ): ?>
            <li><a href=<?php echo e(route( 'logout' )); ?>><span class="glyphicon glyphicon-log-out"></span> Выход</a></li>
        <?php else: ?>
            <li><a href=<?php echo e(route( 'register' )); ?>><span class="glyphicon glyphicon-user"></span> Регистрация</a></li>
            <li><a href=<?php echo e(route( 'login' )); ?>><span class="glyphicon glyphicon-log-in"></span> Вход</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
