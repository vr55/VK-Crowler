<?php $__env->startSection('title'); ?>
Главная страница
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside'); ?>
Главная страница
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php echo $posts->links(); ?>

        </div>
    </div>

    <?php foreach( $posts as $post ): ?>
        <div class="panel panel-default">
          <div class="panel-heading">
              <a target="_blank" href="https://vk.com/wall<?php print $post->owner_id . '_' . $post->vk_id?>"><?php echo e($post->owner_name); ?></a>
              <?php if( date( 'd m Y', $post->date ) == date( 'd m Y' ) ): ?>
              <span class="label label-success">сегодня</span>
              <?php endif; ?>
              <?php if( $post->sent ): ?>
                <span class="label label-primary"><span class="glyphicon glyphicon-ok"></span>&nbsp;отправлено</span>
              <?php endif; ?>
              <div style="font-size: 12px; color: #a9a9a9">
                опубликовано: <?php echo e(date( 'd F Y' ,$post->date )); ?>

              </div>
          </div>
          <div style="padding-left: 15px; padding-top:5px">


          </div>

          <div class="panel-body" style="font-size: 12px; line-height: 1.8">


            <div><?php echo $post->text ?> </div>
          </div>
          <div class="panel-footer">
              <div class="row">
                  <div class="col-md-12">
                    <?php if( $post->from_id > 0 && $post->sent == 0 ): ?>
                        <a href=<?php echo e(route( 'message', $post->from_id )); ?> class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-share-alt"></span> отправить сообщение</a>
                    <?php elseif( $post->signer_id != 0 && $post->sent == 0 ): ?>
                        <a href=<?php echo e(route( 'message', $post->signer_id )); ?> class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-share-alt"></span> отправить сообщение</a>

                    <?php endif; ?>
                    <a href=<?php echo e(route( 'post.delete', $post->id )); ?> class="btn btn-danger btn-xs"><span class="glyphicon glyphicon-remove-sign"></span> удалить</a>
                  </div>

              </div>

          </div>
        </div>


    <?php endforeach; ?>
    <div class="row">
        <div class="col-md-12">
            <?php echo $posts->links(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make( 'layouts.general' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>