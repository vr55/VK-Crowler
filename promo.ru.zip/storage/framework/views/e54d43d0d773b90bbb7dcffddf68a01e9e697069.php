<?php $__env->startSection('title'); ?>
Управление ключевыми словами
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside'); ?>
    <?php if( count( $errors ) > 0 ): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach( $errors->all() as $error): ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <h3>Добавить ключ</h3>
    <?php echo e(Form::open()); ?>

    <div class="input-group">
        <?php echo e(Form::label('ключевое слово')); ?>

        <?php echo e(Form::text( 'keyword', '', ['placeholder' => 'видео'] )); ?>

    </div>
    <?php echo e(Form::submit( 'Добавить', ['class' =>'btn btn-primary', 'style' => 'margin-top: 10px; margin-bottom: 10px'] )); ?>

    <?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="table-responsive">
      <table class="table table-hover">
        <thead>
            <th>
                id
            </th>
            <th>
                url
            </th>
            <th>
                эффективность
            </th>
            <th>
                действие
            </th>
        </thead>
        <tbody>
            <?php foreach( $keywords as $word ): ?>
                <tr>
                    <td>
                        <?php echo e($word->id); ?>

                    </td>
                    <td>
                        <?php echo e($word->keyword); ?>

                    </td>
                    <td>
                        <span class="badge"><?php echo e($word->efficiency); ?></span>
                    </td>
                    <td>
                        <a href=<?php echo e(route( 'keyword.delete', $word->id )); ?> class="btn btn-danger btn-xs">удалить</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="row">
        <div class="col-md-12">
             <?php echo $keywords->links(); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make( 'layouts.general' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>