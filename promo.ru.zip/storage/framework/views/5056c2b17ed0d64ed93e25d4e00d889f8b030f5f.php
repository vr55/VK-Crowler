<?php $__env->startSection('title'); ?>
Вход
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside'); ?>
<div class="row">
<div class="col-md-12">
        <?php echo e(Form::open( [ 'url' => route('register')])); ?>

        <fieldset>
            <!-- Form Name -->
            <legend>Регистрация</legend>

            <!-- Text input-->
            <div class="form-group">
              <label for="name">Email пользователя</label>
              <div>
              <?php echo e(Form::text( 'uName', '', ['placeholder' => 'email', 'class' => 'form-control input-sm chat-input'] )); ?>

              </div>
            </div>

            <div class="form-group">
              <label for="name">Пароль</label>
              <div>
              <?php echo e(Form::password( 'uPassword', ['placeholder' => 'пароль', 'class' => 'form-control input-sm chat-input'] )); ?>

              </div>
            </div>

            <div class="form-group">
              <label for="name">Повторить пароль</label>
              <div>
              <?php echo e(Form::password( 'uPasswordConfirm', ['placeholder' => 'еще раз пароль', 'class' => 'form-control input-sm chat-input'] )); ?>

              </div>
            </div>

            <!-- Button -->
            <div class="form-group">
              <labelfor="reg"></label>
              <div>
                  <?php echo e(Form::submit( 'Регистрация', ['class' => 'btn btn-primary'])); ?>

              </div>
            </div>
        </fieldset>
        <?php echo e(Form::close()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make( 'layouts.general' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>