<?php $__env->startSection('title'); ?>
Вход
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside'); ?>
<div class="row">
<div class="col-md-12">
    <legend>Вход</legend>
        <?php echo e(Form::open()); ?>

        <div class="form-login">
        <input type="text" name="uName" value="<?php echo e(old( 'uName' )); ?>" class="form-control input-sm chat-input" placeholder="e-mail" />
        </br>
        <input type="password" name="uPassword" value="<?php echo e(old('uPassword')); ?>" class="form-control input-sm chat-input" placeholder="пароль" />
        </br>
        <div class="wrapper">
        <span class="group-btn">
            <?php echo e(Form::submit( 'Войти', ['class' => 'btn btn-primary btn-md'] )); ?>

        </span>
        </div>
        </div>
        <?php echo e(Form::close()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make( 'layouts.general' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>