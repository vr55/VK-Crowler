<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use Fabiang\Xmpp\Options;
use Fabiang\Xmpp\Client as Client;
use Fabiang\Xmpp\Protocol\Message as Message;

use App\Models\mcSettings as mcSettings;

class mcXmppController extends mcBaseController
{
    public function getSendMessage()
    {
        $xmpp = mcSettings::firstOrFail()->xmpp;
        if ( !$xmpp )
            return;

        $options = new Options( 'tcp://xmpp.ru:5222' );
        $options->setUsername( 'vk_crawler' )
        ->setPassword( 'owi78gip' );

        $client = new Client($options);

        // optional connect manually
        $client->connect();

        $message = new Message;
        $message->setMessage( 'Привет как дела <a href="#">сылка</a>' )
        ->setTo( 'vr5@jabberzac.org' );
        $client->send( $message );

        $client->disconnect();
    }
}
