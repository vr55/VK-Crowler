<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class mcKeywords extends Model
{
    protected $table = 'mcKeywords';
}
