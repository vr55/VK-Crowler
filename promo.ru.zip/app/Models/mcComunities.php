<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class mcComunities extends Model
{
    protected $table = 'mcComunities';
}
